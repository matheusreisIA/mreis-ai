import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { DatabaseSync } from 'node:sqlite';

export const APP_VERSION = '2.4.0';
export const PORT = Number(process.env.CORE_PORT || 3197);
export const DB_PATH = process.env.CORE_DB_PATH || path.join('data', 'core-runtime.db');
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new DatabaseSync(DB_PATH);
db.exec(`
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,credits INTEGER NOT NULL DEFAULT 20,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,input TEXT NOT NULL,result TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,project_id TEXT NOT NULL,data TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,product_id TEXT NOT NULL,status TEXT NOT NULL,amount INTEGER NOT NULL,currency TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,type TEXT NOT NULL,product_id TEXT,created_at TEXT NOT NULL);
`);

const now=()=>new Date().toISOString();
const id=()=>crypto.randomUUID();
const send=(res,status,body,headers={})=>{const raw=typeof body==='string'?Buffer.from(body):Buffer.from(JSON.stringify(body));res.writeHead(status,{'content-type':typeof body==='string'?'text/plain; charset=utf-8':'application/json; charset=utf-8','content-length':raw.length,'x-request-id':id(),...headers});res.end(raw);};
const readBody=req=>new Promise((resolve,reject)=>{let b='';req.on('data',c=>{b+=c;if(b.length>2_000_000){reject(new Error('payload too large'));req.destroy();}});req.on('end',()=>{try{resolve(b?JSON.parse(b):{})}catch{reject(new Error('invalid json'))}});req.on('error',reject)});
const bearer=req=>req.headers.authorization?.replace(/^Bearer\s+/i,'');
const auth=req=>{const raw=bearer(req);if(!raw)return null;const s=db.prepare('SELECT * FROM sessions WHERE id=? AND expires_at>?').get(raw,now());return s?db.prepare('SELECT * FROM users WHERE id=?').get(s.user_id):null;};
const demo=()=>{let u=db.prepare('SELECT * FROM users WHERE email=?').get('demo@mreis.ai');if(!u){u={id:id(),email:'demo@mreis.ai',credits:20,created_at:now()};db.prepare('INSERT INTO users VALUES (?,?,?,?)').run(u.id,u.email,u.credits,u.created_at)}const token=crypto.randomBytes(24).toString('hex');db.prepare('INSERT INTO sessions VALUES (?,?,?)').run(token,u.id,new Date(Date.now()+3600_000).toISOString());return {token,user:u}};
const opportunity=input=>({opportunity:`A testable digital-product opportunity for ${input.market||'an international market'} in ${input.category||'productivity'}.`,audience:'A narrowly defined audience with the selected problem.',problem:input.problem||'A recurring problem that can be solved with a practical system.',desiredOutcome:'A clear measurable improvement.',productName:'MReis Starter System',format:'Guide + workbook + checklist + templates',offer:'A practical system with implementation steps and ready-to-use resources.',priceHypothesis:'Validate willingness to pay before scaling.'});
const pdf=(product)=>{const text=(product.title||'MReis Digital Product').replace(/[()]/g,'');const stream=`BT /F1 20 Tf 72 760 Td (${text}) Tj /F1 12 Tf 0 -32 Td (Created with MReis AI) Tj ET`;const objs=[`<< /Type /Catalog /Pages 2 0 R >>`,`<< /Type /Pages /Kids [3 0 R] /Count 1 >>`,`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>`,`<< /Length ${Buffer.byteLength(stream)} >>\\nstream\\n${stream}\\nendstream`,`<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>`];let out='%PDF-1.4\\n',offs=[0];for(let i=0;i<objs.length;i++){offs.push(Buffer.byteLength(out));out+=`${i+1} 0 obj\\n${objs[i]}\\nendobj\\n`}const x=Buffer.byteLength(out);out+=`xref\\n0 ${objs.length+1}\\n0000000000 65535 f \\n`;for(let i=1;i<offs.length;i++)out+=`${String(offs[i]).padStart(10,'0')} 00000 n \\n`;out+=`trailer << /Size ${objs.length+1} /Root 1 0 R >>\\nstartxref\\n${x}\\n%%EOF`;return Buffer.from(out.replaceAll('\\\\n','\\n'))};

export const server=http.createServer(async(req,res)=>{
  try{
    const u=new URL(req.url,`http://127.0.0.1:${PORT}`);const p=u.pathname;
    if(req.method==='GET'&&p==='/api/health')return send(res,200,{ok:true,service:'mreis-ai-core',version:APP_VERSION,mode:'core-runtime'});
    if(req.method==='GET'&&p==='/api/health/ready'){db.prepare('SELECT 1').get();return send(res,200,{ok:true,ready:true,db:true,version:APP_VERSION})}
    if(req.method==='POST'&&p==='/api/auth/demo')return send(res,200,{...demo(),demo:true});
    const user=auth(req);if(!user)return send(res,401,{error:'Authentication required'});
    if(req.method==='POST'&&p==='/api/discover'){const b=await readBody(req);const result=opportunity(b);const projectId=id();db.prepare('INSERT INTO projects VALUES (?,?,?,?,?)').run(projectId,user.id,JSON.stringify(b),JSON.stringify(result),now());db.prepare('INSERT INTO events VALUES (?,?,?,?,?)').run(id(),user.id,'discover',null,now());return send(res,200,{projectId,result})}
    if(req.method==='POST'&&p==='/api/products/generate'){const b=await readBody(req);const project=db.prepare('SELECT * FROM projects WHERE id=? AND user_id=?').get(b.projectId,user.id);if(!project)return send(res,404,{error:'Project not found'});const base=JSON.parse(project.result);const product={id:id(),title:b.title||base.productName,promise:base.desiredOutcome,audience:base.audience,format:base.format,offer:base.offer,priceHypothesis:base.priceHypothesis};db.prepare('INSERT INTO products VALUES (?,?,?,?,?)').run(product.id,user.id,project.id,JSON.stringify(product),now());return send(res,200,{productId:product.id,product})}
    const m=p.match(/^\/api\/products\/([^/]+)\/pdf$/);if(req.method==='GET'&&m){const product=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(m[1],user.id);if(!product)return send(res,404,{error:'Product not found'});const body=pdf(JSON.parse(product.data));res.writeHead(200,{'content-type':'application/pdf','content-length':body.length,'content-disposition':'attachment; filename="mreis-product.pdf"'});return res.end(body)}
    if(req.method==='POST'&&p==='/api/test/checkout'){const b=await readBody(req);const product=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(b.productId,user.id);if(!product)return send(res,404,{error:'Product not found'});const orderId=id();db.exec('BEGIN');try{db.prepare('INSERT INTO orders VALUES (?,?,?,?,?,?,?)').run(orderId,user.id,product.id,'paid',Number(b.priceCents||1490),String(b.currency||'eur'),now());db.prepare('INSERT INTO events VALUES (?,?,?,?,?)').run(id(),user.id,'purchase',product.id,now());db.exec('COMMIT')}catch(e){db.exec('ROLLBACK');throw e}return send(res,200,{orderId,status:'paid',deliveryUrl:`/api/orders/${orderId}/delivery`})}
    const d=p.match(/^\/api\/orders\/([^/]+)\/delivery$/);if(req.method==='GET'&&d){const o=db.prepare('SELECT * FROM orders WHERE id=? AND user_id=?').get(d[1],user.id);if(!o)return send(res,404,{error:'Order not found'});return send(res,200,{orderId:o.id,status:o.status,productId:o.product_id,pdfUrl:`/api/products/${o.product_id}/pdf`})}
    if(req.method==='GET'&&p==='/api/analytics'){const products=db.prepare('SELECT COUNT(*) c FROM products WHERE user_id=?').get(user.id).c;const purchases=db.prepare("SELECT COUNT(*) c FROM orders WHERE user_id=? AND status='paid'").get(user.id).c;const discoveries=db.prepare("SELECT COUNT(*) c FROM events WHERE user_id=? AND type='discover'").get(user.id).c;return send(res,200,{products,purchases,discoveries,conversionRate:discoveries?Math.round(purchases/discoveries*1000)/10:0})}
    return send(res,404,{error:'Not found'});
  }catch(e){return send(res,500,{error:'Unexpected core runtime error',detail:e.message})}
});

if(import.meta.url===`file://${process.argv[1]}`){
 server.listen(PORT,()=>console.log(`MReis AI Core v${APP_VERSION} running at http://127.0.0.1:${PORT}`));
 const shutdown=()=>server.close(()=>{try{db.close()}finally{process.exit(0)}});process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
}
