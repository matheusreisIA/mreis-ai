import 'dotenv/config';
import express from 'express';
import Database from 'better-sqlite3';
import OpenAI from 'openai';
import Stripe from 'stripe';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import PDFDocument from 'pdfkit';

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_VERSION = '2.4.0';
const BASE_URL = process.env.BASE_URL || `http://localhost:${PORT}`;
const DB_PATH = process.env.DB_PATH || 'data/mreis.db';
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,password_hash TEXT NOT NULL,created_at TEXT NOT NULL,plan TEXT NOT NULL DEFAULT 'free',credits INTEGER NOT NULL DEFAULT 20);
CREATE TABLE IF NOT EXISTS sessions(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,expires_at TEXT NOT NULL,created_at TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS projects(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,created_at TEXT NOT NULL,input TEXT NOT NULL,result TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY,user_id TEXT NOT NULL,project_id TEXT,created_at TEXT NOT NULL,data TEXT NOT NULL,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,user_id TEXT,product_id TEXT,created_at TEXT NOT NULL,status TEXT NOT NULL,amount INTEGER,currency TEXT,email TEXT,provider_id TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS events(id TEXT PRIMARY KEY,user_id TEXT,type TEXT NOT NULL,product_id TEXT,created_at TEXT NOT NULL,metadata TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS webhook_events(id TEXT PRIMARY KEY,provider TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS idempotency_keys(key TEXT NOT NULL,user_id TEXT NOT NULL,route TEXT NOT NULL,response_json TEXT NOT NULL,created_at TEXT NOT NULL,PRIMARY KEY(key,user_id,route));
`);
// Cleanup runs only after the schema exists. This is intentionally after migrations/schema creation.
db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(new Date().toISOString());
const openai = process.env.OPENAI_API_KEY ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY }) : null;
const stripe = process.env.STRIPE_SECRET_KEY ? new Stripe(process.env.STRIPE_SECRET_KEY) : null;
const IS_PRODUCTION = process.env.NODE_ENV === 'production';
const REQUIRED_PRODUCTION_VARS = ['OPENAI_API_KEY','OPENAI_MODEL','STRIPE_SECRET_KEY','STRIPE_WEBHOOK_SECRET','BASE_URL','TRUST_PROXY'];
function productionConfigIssues(){ return REQUIRED_PRODUCTION_VARS.filter(k=>!String(process.env[k]||'').trim()).map(k=>k==='TRUST_PROXY'?'TRUST_PROXY=true is required behind a proxy':`${k} is required`); }
if(IS_PRODUCTION){ const issues=productionConfigIssues(); if(issues.length){ console.error('Production configuration incomplete:', issues.join('; ')); } }
const PLAN_LIMITS = { free: 20, starter: 100, pro: 500, business: 2000 };
const apiLimiter = rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many requests. Try again shortly.' } });
const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: 'draft-8', legacyHeaders: false, message: { error: 'Too many authentication attempts. Try again later.' } });

function now(){ return new Date().toISOString(); }
function hash(password,salt){ return crypto.scryptSync(password,salt,64).toString('hex')+':'+salt; }
function verify(password,stored){ try { const [hex,salt]=stored.split(':'); const a=Buffer.from(hex,'hex'); const b=Buffer.from(hash(password,salt).split(':')[0],'hex'); return a.length===b.length&&crypto.timingSafeEqual(a,b); } catch { return false; } }
function token(){ return crypto.randomBytes(32).toString('hex'); }
function sessionId(raw){ return crypto.createHash('sha256').update(raw).digest('hex'); }
function userFromReq(req){ const raw=req.headers.authorization?.replace(/^Bearer\s+/i,''); if(!raw)return null; const sid=sessionId(raw); const s=db.prepare('SELECT * FROM sessions WHERE id=?').get(sid); if(!s)return null; if(new Date(s.expires_at)<new Date()){db.prepare('DELETE FROM sessions WHERE id=?').run(sid);return null;} return db.prepare('SELECT * FROM users WHERE id=?').get(s.user_id); }
function auth(req,res,next){ const u=userFromReq(req); if(!u)return res.status(401).json({error:'Authentication required'}); req.user=u; next(); }
function saveEvent(user,type,productId=null,metadata={}){ db.prepare('INSERT INTO events VALUES (?,?,?,?,?,?)').run(crypto.randomUUID(),user?.id||null,type,productId,now(),JSON.stringify(metadata)); }
function consumeCredits(user,cost){ const result=db.prepare('UPDATE users SET credits=credits-? WHERE id=? AND credits>=?').run(cost,user.id,cost); return result.changes===1; }
function refundCredits(userId,cost){ db.prepare('UPDATE users SET credits=credits+? WHERE id=?').run(cost,userId); }

const SYSTEM=`You are MReis AI, an international digital-product strategist. Help users discover, build and launch useful digital products ethically. Never promise sales. Never fabricate market evidence, demand, competition, testimonials or prices. Label assumptions as hypotheses. Avoid regulated/high-risk advice. Return strict JSON only.`;
function demo(input){ return { opportunity:`A testable digital-product opportunity in ${input.category||'productivity'} for ${input.market||'an international market'}.`, audience:'A narrowly defined audience experiencing the selected problem', problem:input.problem||'A recurring problem that can be solved with a practical system', desiredOutcome:'A clear, measurable improvement', productName:'MReis Starter System', format:'Guide + workbook + checklist + templates', offer:'A practical system with implementation steps and ready-to-use resources', priceHypothesis:'Validate willingness to pay with a small paid test before scaling', blueprint:['Promise and scope','Diagnosis','Core framework','Implementation plan','Templates','Checklist','Next steps'], salesPage:{headline:'A practical system for a problem that keeps getting in the way.',subheadline:'A focused digital product built around one measurable outcome.',cta:'Get instant access'}, contentIdeas:['Problem/solution short video','Three common mistakes','Quick tutorial','Before/after workflow','FAQ objection video'], validationPlan:['Interview 5–10 target users','Publish a landing page','Measure qualified clicks','Run a small paid test','Compare offer and price variants']}; }
async function aiJson(payload){
  if(!openai)return demo(payload);
  const r=await openai.responses.create({model:process.env.OPENAI_MODEL||'gpt-5.6-luna',input:[{role:'system',content:SYSTEM},{role:'user',content:JSON.stringify(payload)}],text:{format:{type:'json_object'}}});
  return JSON.parse(r.output_text);
}

app.disable('x-powered-by');
app.use((req,res,next)=>{ req.requestId=crypto.randomUUID(); res.setHeader('X-Request-Id',req.requestId); next(); });
app.set('trust proxy', process.env.TRUST_PROXY==='true');
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use('/api', apiLimiter);
app.use('/api/auth', authLimiter);
app.use('/api/stripe/webhook',express.raw({type:'application/json'}));
app.use((req,res,next)=>{ if(req.path==='/api/stripe/webhook')return next(); express.json({limit:'2mb'})(req,res,next); });
app.use(express.static('public',{maxAge:process.env.NODE_ENV==='production'?'1d':0}));

app.get('/api/health',(req,res)=>res.json({ok:true,service:'mreis-ai',version:APP_VERSION,mode:openai?'ai':'demo',timestamp:now(),requestId:req.requestId}));
app.get('/api/health/config',(req,res)=>{
  const checks={database:!!db,openai:!!openai,stripe:!!stripe,webhookSecret:!!process.env.STRIPE_WEBHOOK_SECRET,baseUrl:!!process.env.BASE_URL,trustProxy:process.env.TRUST_PROXY==='true',nodeEnv:IS_PRODUCTION};
  const issues=productionConfigIssues();
  const productionReady=issues.length===0 && checks.database;
  res.status(productionReady?200:503).json({ok:productionReady,environment:process.env.NODE_ENV||'development',checks,issues,mode:productionReady?'production-ready':'configuration-incomplete',requestId:req.requestId});
});
app.get('/api/health/ready',(req,res)=>{
  try { db.prepare('SELECT 1').get(); res.json({ok:true,ready:true,db:true,ai:!!openai,stripe:!!stripe,version:APP_VERSION,timestamp:now(),requestId:req.requestId}); }
  catch { res.status(503).json({ok:false,ready:false,db:false,version:APP_VERSION,timestamp:now(),requestId:req.requestId}); }
});
app.post('/api/auth/demo', (req,res)=>{ try { const email='demo@mreis.ai'; let u=db.prepare('SELECT * FROM users WHERE email=?').get(email); if(!u){ const id=crypto.randomUUID(); const salt=crypto.randomBytes(16).toString('hex'); db.prepare('INSERT INTO users VALUES (?,?,?,?,?,?,?)').run(id,email,hash(crypto.randomBytes(18).toString('hex'),salt),now(),'free',PLAN_LIMITS.free); u=db.prepare('SELECT * FROM users WHERE id=?').get(id); } const sid=token(); db.prepare('INSERT INTO sessions VALUES (?,?,?,?)').run(sessionId(sid),u.id,new Date(Date.now()+1000*60*60*4).toISOString(),now()); res.json({token:sid,user:{id:u.id,email:'Demo workspace',plan:u.plan,credits:u.credits},demo:true}); } catch(e){ res.status(500).json({error:'Unable to start demo workspace.'}); }});


app.post('/api/auth/register',(req,res)=>{try{const email=String(req.body?.email||'').trim().toLowerCase();const password=String(req.body?.password||'');if(!/^\S+@\S+\.\S+$/.test(email)||password.length<8||password.length>128)return res.status(400).json({error:'Use a valid email and a password of at least 8 characters.'});if(db.prepare('SELECT id FROM users WHERE email=?').get(email))return res.status(409).json({error:'Email already registered.'});const id=crypto.randomUUID();const salt=crypto.randomBytes(16).toString('hex');db.prepare('INSERT INTO users VALUES (?,?,?,?,?,?,?)').run(id,email,hash(password,salt),now(),'free',PLAN_LIMITS.free);const sid=token();db.prepare('INSERT INTO sessions VALUES (?,?,?,?)').run(sessionId(sid),id,new Date(Date.now()+1000*60*60*24*30).toISOString(),now());res.json({token:sid,user:{id,email,plan:'free',credits:PLAN_LIMITS.free}});}catch(e){res.status(500).json({error:'Unable to create account.'});}});
app.post('/api/auth/login',(req,res)=>{const email=String(req.body?.email||'').trim().toLowerCase(),password=String(req.body?.password||'');const u=db.prepare('SELECT * FROM users WHERE email=?').get(email);if(!u||!verify(password,u.password_hash))return res.status(401).json({error:'Invalid credentials.'});const sid=token();db.prepare('INSERT INTO sessions VALUES (?,?,?,?)').run(sessionId(sid),u.id,new Date(Date.now()+1000*60*60*24*30).toISOString(),now());res.json({token:sid,user:{id:u.id,email:u.email,plan:u.plan,credits:u.credits}});});
app.post('/api/auth/logout',auth,(req,res)=>{const t=req.headers.authorization.replace(/^Bearer\s+/i,'');db.prepare('DELETE FROM sessions WHERE id=?').run(sessionId(t));res.json({ok:true});});
app.get('/api/me',auth,(req,res)=>res.json({id:req.user.id,email:req.user.email,plan:req.user.plan,credits:req.user.credits}));
app.get('/api/account/export',auth,(req,res)=>{const uid=req.user.id;const payload={user:{id:req.user.id,email:req.user.email,plan:req.user.plan,credits:req.user.credits,createdAt:req.user.created_at},projects:db.prepare('SELECT id,created_at,input,result FROM projects WHERE user_id=? ORDER BY created_at').all(uid).map(x=>({...x,input:JSON.parse(x.input),result:JSON.parse(x.result)})),products:db.prepare('SELECT id,project_id,created_at,data FROM products WHERE user_id=? ORDER BY created_at').all(uid).map(x=>({...x,data:JSON.parse(x.data)})),orders:db.prepare('SELECT id,product_id,created_at,status,amount,currency,email,provider_id FROM orders WHERE user_id=? ORDER BY created_at').all(uid),events:db.prepare('SELECT type,product_id,created_at,metadata FROM events WHERE user_id=? ORDER BY created_at').all(uid).map(x=>({...x,metadata:JSON.parse(x.metadata)}))};res.setHeader('Content-Type','application/json');res.setHeader('Content-Disposition','attachment; filename=\"mreis-account-export.json\"');res.json(payload);});
app.delete('/api/account',auth,(req,res)=>{const uid=req.user.id;const confirmation=String(req.body?.confirmation||'');if(confirmation!=='DELETE MY ACCOUNT')return res.status(400).json({error:'Type DELETE MY ACCOUNT to confirm account deletion.'});db.prepare('DELETE FROM users WHERE id=?').run(uid);res.json({ok:true,deleted:true});});

app.post('/api/discover',auth,async(req,res)=>{const cost=1;if(!req.body?.market||!req.body?.category)return res.status(400).json({error:'Market and category are required.'});if(!consumeCredits(req.user,cost))return res.status(402).json({error:'Insufficient AI credits.'});try{const result=await aiJson(req.body);const id=crypto.randomUUID();db.prepare('INSERT INTO projects VALUES (?,?,?,?,?)').run(id,req.user.id,now(),JSON.stringify(req.body),JSON.stringify(result));saveEvent(req.user,'discover');const credits=db.prepare('SELECT credits FROM users WHERE id=?').get(req.user.id).credits;res.json({id,result,demo:!openai,creditsRemaining:credits});}catch(e){refundCredits(req.user.id,cost);res.status(502).json({error:'AI generation failed. Your credit was restored.'});}});

app.post('/api/products/generate',auth,async(req,res)=>{const cost=2;const row=db.prepare('SELECT * FROM projects WHERE id=? AND user_id=?').get(req.body?.projectId,req.user.id);if(!row)return res.status(404).json({error:'Project not found.'});if(!consumeCredits(req.user,cost))return res.status(402).json({error:'Insufficient AI credits.'});try{const base=JSON.parse(row.result);const result=await aiJson({task:'Build the complete first version of this digital product. Produce a substantive but concise blueprint suitable for PDF/workbook export. Include title, promise, audience, outcome structure, modules, exercises, checklists, templates, disclaimer where relevant, and quality-control checklist.',source:base,overrides:req.body?.overrides||{}});const id=crypto.randomUUID();db.prepare('INSERT INTO products VALUES (?,?,?,?,?)').run(id,req.user.id,row.id,now(),JSON.stringify(result));saveEvent(req.user,'product_created',id);const credits=db.prepare('SELECT credits FROM users WHERE id=?').get(req.user.id).credits;res.json({id,result,demo:!openai,creditsRemaining:credits});}catch(e){refundCredits(req.user.id,cost);res.status(502).json({error:'Product generation failed. Your credits were restored.'});}});
app.patch('/api/products/:id',auth,(req,res)=>{ const row=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.params.id,req.user.id); if(!row)return res.status(404).json({error:'Product not found.'}); const current=JSON.parse(row.data); const patch=req.body?.data; if(!patch || typeof patch!=='object') return res.status(400).json({error:'Product data required.'}); const merged={...current,...patch}; db.prepare('UPDATE products SET data=? WHERE id=? AND user_id=?').run(JSON.stringify(merged),req.params.id,req.user.id); saveEvent(req.user,'product_updated',req.params.id); res.json({id:row.id,data:merged}); });

app.get('/api/products/:id',auth,(req,res)=>{const row=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.params.id,req.user.id);if(!row)return res.status(404).json({error:'Product not found.'});res.json({...row,data:JSON.parse(row.data)});});
app.get('/api/products',auth,(req,res)=>{const rows=db.prepare('SELECT id,project_id,created_at,data FROM products WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id);res.json(rows.map(x=>({...x,data:JSON.parse(x.data)})));});

app.post('/api/campaigns/generate',auth,async(req,res)=>{const cost=2;const row=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.body?.productId,req.user.id);if(!row)return res.status(404).json({error:'Product not found.'});if(!consumeCredits(req.user,cost))return res.status(402).json({error:'Insufficient AI credits.'});try{const product=JSON.parse(row.data);const result=await aiJson({task:'Create a complete launch kit for this digital product.',market:req.body?.market||'Global',language:req.body?.language||'English',product,deliverables:['sales page','10 short-form video hooks','10 social posts','5 emails','5 ad concepts','FAQ','objection responses','checkout copy','post-purchase message'],rules:['No guaranteed results','No fabricated testimonials','No false scarcity','Label assumptions']});saveEvent(req.user,'campaign_created',row.id);const credits=db.prepare('SELECT credits FROM users WHERE id=?').get(req.user.id).credits;res.json({result,demo:!openai,creditsRemaining:credits});}catch(e){refundCredits(req.user.id,cost);res.status(502).json({error:'Launch generation failed. Your credits were restored.'});}});

app.get('/api/projects',auth,(req,res)=>{const rows=db.prepare('SELECT id,created_at,input,result FROM projects WHERE user_id=? ORDER BY created_at DESC LIMIT 50').all(req.user.id);res.json(rows.map(x=>({...x,input:JSON.parse(x.input),result:JSON.parse(x.result)})));});
app.post('/api/events',auth,(req,res)=>{if(!req.body?.type)return res.status(400).json({error:'Event type required.'});saveEvent(req.user,req.body.type,req.body.productId,req.body.metadata||{});res.json({ok:true});});

function buildPdf(product,title){return new Promise(resolve=>{const doc=new PDFDocument({margin:50});const chunks=[];doc.on('data',c=>chunks.push(c));doc.on('end',()=>resolve(Buffer.concat(chunks)));doc.fontSize(24).text(title||product.title||'MReis Digital Product');doc.moveDown();doc.fontSize(11);const walk=(v,depth=0)=>{if(v===null||v===undefined)return;if(typeof v==='string'||typeof v==='number'||typeof v==='boolean'){doc.text(String(v));return;}if(Array.isArray(v)){for(const x of v){if(typeof x==='object'){doc.moveDown(.2);walk(x,depth+1);}else doc.text(`• ${x}`);}return;}for(const [k,val] of Object.entries(v)){doc.moveDown(.35);doc.fontSize(Math.max(11,15-depth)).text(k.replace(/([A-Z])/g,' $1').replace(/^./,s=>s.toUpperCase()));doc.fontSize(11);walk(val,depth+1);}};walk(product);doc.end();});}
app.get('/api/products/:id/pdf',auth,async(req,res)=>{const row=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.params.id,req.user.id);if(!row)return res.status(404).json({error:'Product not found.'});const pdf=await buildPdf(JSON.parse(row.data));res.setHeader('Content-Type','application/pdf');res.setHeader('Content-Disposition',`attachment; filename="mreis-product-${row.id}.pdf"`);res.send(pdf);});

app.post('/api/test/checkout',auth,(req,res)=>{
  const {productId,priceCents=1490,currency='eur'}=req.body||{};
  if(!productId||!db.prepare('SELECT id FROM products WHERE id=? AND user_id=?').get(productId,req.user.id)) return res.status(404).json({error:'Product not found.'});
  if(!Number.isInteger(priceCents)||priceCents<100||priceCents>10000000) return res.status(400).json({error:'Invalid price.'});
  const key=String(req.headers['idempotency-key']||'').trim();
  if(key.length>128)return res.status(400).json({error:'Idempotency-Key is too long.'});
  if(key){const prior=db.prepare('SELECT response_json FROM idempotency_keys WHERE key=? AND user_id=? AND route=?').get(key,req.user.id,'/api/test/checkout');if(prior)return res.json(JSON.parse(prior.response_json));}
  const orderId=crypto.randomUUID();
  const response={ok:true,orderId,test:true,status:'paid',deliveryUrl:`/api/orders/${orderId}/delivery`};
  const tx=db.transaction(()=>{db.prepare('INSERT INTO orders VALUES (?,?,?,?,?,?,?,?,?)').run(orderId,req.user.id,productId,now(),'paid',priceCents,String(currency).toLowerCase(),req.user.email,'test_'+orderId);saveEvent(req.user,'purchase',productId,{test:true,amount:priceCents,currency:String(currency).toLowerCase()});if(key)db.prepare('INSERT INTO idempotency_keys VALUES (?,?,?,?,?)').run(key,req.user.id,'/api/test/checkout',JSON.stringify(response),now());});
  tx();
  res.json(response);
});
app.get('/api/orders/:id/delivery',auth,(req,res)=>{
  const order=db.prepare('SELECT * FROM orders WHERE id=? AND user_id=? AND status=?').get(req.params.id,req.user.id,'paid');
  if(!order)return res.status(404).json({error:'Order not found.'});
  const product=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(order.product_id,req.user.id);
  if(!product)return res.status(404).json({error:'Product not found.'});
  const data=JSON.parse(product.data);
  res.json({orderId:order.id,productId:product.id,title:data.title||data.productName||'MReis Digital Product',message:'Test purchase confirmed. Your digital product is ready.',pdfUrl:`/api/products/${product.id}/pdf`});
});
app.get('/api/analytics',auth,(req,res)=>{
  const userId=req.user.id;
  const events=db.prepare('SELECT type,COUNT(*) c FROM events WHERE user_id=? GROUP BY type').all(userId);
  const map=Object.fromEntries(events.map(x=>[x.type,x.c]));
  const paid=db.prepare("SELECT COUNT(*) c FROM orders WHERE user_id=? AND status='paid'").get(userId).c;
  const revenue=db.prepare("SELECT COALESCE(SUM(amount),0) c FROM orders WHERE user_id=? AND status='paid'").get(userId).c;
  const products=db.prepare('SELECT COUNT(*) c FROM products WHERE user_id=?').get(userId).c;
  const projects=db.prepare('SELECT COUNT(*) c FROM projects WHERE user_id=?').get(userId).c;
  res.json({projects,products,discoveries:map.discover||0,launches:map.campaign_created||0,checkouts:map.checkout_created||0,purchases:paid,revenueMinorUnits:revenue,currency:'EUR',conversionRate:map.checkout_created?Math.round((paid/map.checkout_created)*1000)/10:0});
});
app.get('/api/products/:id/launch-page',auth,(req,res)=>{
  const row=db.prepare('SELECT * FROM products WHERE id=? AND user_id=?').get(req.params.id,req.user.id);
  if(!row)return res.status(404).json({error:'Product not found.'});
  const product=JSON.parse(row.data);
  res.json({productId:row.id,title:product.title||product.productName||'MReis Digital Product',promise:product.promise||product.desiredOutcome||'A focused digital product built around one measurable outcome.',audience:product.audience||'',format:product.format||'Digital product',offer:product.offer||'',priceHypothesis:product.priceHypothesis||'',cta:'Get instant access',testMode:true});
});
app.post('/api/stripe/create-checkout',auth,async(req,res)=>{if(!stripe)return res.status(503).json({error:'Stripe is not configured.'});const {productId,name='MReis Digital Product',priceCents=1490,currency='eur'}=req.body||{};if(!Number.isInteger(priceCents)||priceCents<100||priceCents>10000000)return res.status(400).json({error:'Invalid price.'});if(productId&&!db.prepare('SELECT id FROM products WHERE id=? AND user_id=?').get(productId,req.user.id))return res.status(404).json({error:'Product not found.'});try{const session=await stripe.checkout.sessions.create({mode:'payment',line_items:[{price_data:{currency:String(currency).toLowerCase(),product_data:{name:String(name).slice(0,120)},unit_amount:priceCents},quantity:1}],customer_email:req.user.email,metadata:{productId:productId||'',userId:req.user.id},success_url:`${BASE_URL}/?paid=1&session_id={CHECKOUT_SESSION_ID}`,cancel_url:`${BASE_URL}/?cancelled=1`});saveEvent(req.user,'checkout_created',productId,{sessionId:session.id});res.json({url:session.url});}catch(e){res.status(502).json({error:'Unable to create checkout.'});}});
app.post('/api/stripe/webhook',(req,res)=>{if(!stripe||!process.env.STRIPE_WEBHOOK_SECRET)return res.status(503).end();try{const event=stripe.webhooks.constructEvent(req.body,req.headers['stripe-signature'],process.env.STRIPE_WEBHOOK_SECRET);if(db.prepare('SELECT id FROM webhook_events WHERE id=?').get(event.id))return res.json({received:true,duplicate:true});db.prepare('INSERT INTO webhook_events VALUES (?,?,?)').run(event.id,'stripe',now());if(event.type==='checkout.session.completed'){const s=event.data.object;db.prepare('INSERT OR IGNORE INTO orders VALUES (?,?,?,?,?,?,?,?,?)').run(crypto.randomUUID(),s.metadata?.userId||null,s.metadata?.productId||null,now(),'paid',s.amount_total,s.currency,s.customer_details?.email||null,s.id);const u=s.metadata?.userId?db.prepare('SELECT * FROM users WHERE id=?').get(s.metadata.userId):null;saveEvent(u,'purchase',s.metadata?.productId,{sessionId:s.id,amount:s.amount_total,currency:s.currency});}res.json({received:true});}catch(e){res.status(400).send('Webhook Error');}});
app.get('/api/admin/metrics',auth,(req,res)=>{if(req.user.plan!=='business')return res.status(403).json({error:'Business plan required.'});const users=db.prepare('SELECT COUNT(*) c FROM users').get().c;const paid=db.prepare("SELECT COUNT(*) c FROM orders WHERE status='paid'").get().c;const revenue=db.prepare("SELECT COALESCE(SUM(amount),0) c FROM orders WHERE status='paid'").get().c;const discoveries=db.prepare("SELECT COUNT(*) c FROM events WHERE type='discover'").get().c;const products=db.prepare("SELECT COUNT(*) c FROM products").get().c;res.json({users,paidOrders:paid,revenueMinorUnits:revenue,discoveries,products});});

app.use((req,res,next)=>{if(req.path.startsWith('/api/'))return res.status(404).json({error:'Not found.'});next();});
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:'Unexpected server error.'});});
const server = app.listen(PORT,()=>console.log(`MReis AI v${APP_VERSION} running at ${BASE_URL}`));
server.requestTimeout = Number(process.env.REQUEST_TIMEOUT_MS || 30000);
server.headersTimeout = Number(process.env.HEADERS_TIMEOUT_MS || 35000);
server.keepAliveTimeout = Number(process.env.KEEP_ALIVE_TIMEOUT_MS || 5000);
let shuttingDown=false;
async function shutdown(signal){
  if(shuttingDown)return;
  shuttingDown=true;
  console.log(`MReis AI shutdown requested: ${signal}`);
  await new Promise(resolve=>server.close(resolve));
  try{db.close();}finally{process.exit(0);}
}
process.on('SIGTERM',()=>void shutdown('SIGTERM'));
process.on('SIGINT',()=>void shutdown('SIGINT'));
process.on('uncaughtException',err=>{console.error('UNCAUGHT_EXCEPTION',err);void shutdown('uncaughtException');});
process.on('unhandledRejection',err=>{console.error('UNHANDLED_REJECTION',err);void shutdown('unhandledRejection');});
