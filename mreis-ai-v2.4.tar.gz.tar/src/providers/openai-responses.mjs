/**
 * Production OpenAI adapter.
 * Uses the Responses API; credentials remain server-side.
 */
export async function generateJson({ client, model='gpt-5.6-luna', system, payload }) {
  if (!client) throw new Error('OpenAI client is not configured');
  const response = await client.responses.create({
    model,
    input: [
      { role: 'system', content: system },
      { role: 'user', content: JSON.stringify(payload) }
    ],
    text: { format: { type: 'json_object' } }
  });
  return JSON.parse(response.output_text);
}
