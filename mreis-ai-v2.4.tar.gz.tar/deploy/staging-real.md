# MReis AI — Real Staging Runbook

## Goal

Validate the complete MReis AI journey against real staging infrastructure without exposing production credentials or charging real customers.

## 1. Supabase

- Create a dedicated staging project.
- Create the current publishable and secret API keys.
- Apply `supabase/migrations/001_initial.sql`.
- Execute `supabase/tests/rls.sql` and review every policy.
- Confirm backups/retention appropriate to the staging project.

Use the publishable key only in public/client contexts and the secret key only on the backend. The secret key bypasses RLS. See the current Supabase API-key guidance.

## 2. OpenAI

- Create/use a dedicated API key for staging.
- Set `OPENAI_MODEL=gpt-5.6-luna` unless a different approved staging model is selected.
- Configure spend/rate limits appropriate to testing.
- Run `npm run staging:smoke`.
- Confirm the response provider returns structured JSON for Discover/Product generation.

## 3. Stripe

- Use Stripe test/sandbox credentials for staging.
- Set `STRIPE_SECRET_KEY` to the test-mode secret key.
- Configure the staging webhook endpoint.
- Set `STRIPE_WEBHOOK_SECRET` from the webhook configuration.
- Test `checkout.session.completed` and failure/retry behavior.
- Confirm idempotency prevents duplicate order creation.

## 4. HTTPS

Set `BASE_URL` to the actual HTTPS staging origin. Do not use an insecure public URL for real credential testing.

## 5. External E2E

Run this sequence with a disposable staging account:

1. health/readiness
2. sign in
3. Discover
4. generate product
5. export PDF
6. create test checkout
7. complete Stripe test payment
8. receive/verify webhook
9. retrieve delivery
10. inspect analytics
11. force an AI failure and confirm credit refund
12. retry a checkout with the same idempotency key and confirm no duplicate order
13. export account data
14. test explicit account deletion

## 6. Security checks

- No secrets in Git.
- No secrets in browser bundles.
- No secrets in logs.
- Request IDs present.
- Rate limiting active.
- Helmet/security headers active.
- Webhook signatures verified.
- Sessions stored using hashed identifiers in the production server path.
- Database foreign keys and transactional checkout enabled.

## 7. Exit criteria

Staging is considered technically validated only when all external checks pass and the complete E2E sequence succeeds. A passing local test suite alone does not constitute production readiness.
