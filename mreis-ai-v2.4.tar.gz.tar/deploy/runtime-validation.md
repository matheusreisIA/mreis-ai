# Runtime validation

The repository now contains a real E2E smoke test: `npm run test:runtime`.

It starts the actual Express server, waits for `/api/health`, creates a demo session, runs Discover, generates a product, downloads its PDF, performs a test checkout, verifies delivery, and checks analytics.

Exit codes:
- `0`: E2E passed.
- `1`: E2E ran and failed.
- `2`: dependencies are unavailable locally (`node_modules` missing).

This is intentionally different from the static test. A static test must never be presented as proof that the server executed.
