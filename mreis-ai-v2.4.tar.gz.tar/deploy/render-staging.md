# MReis AI — Render Staging Deployment

This deployment target is intentionally a persistent Node/Docker service. The current MReis AI runtime uses SQLite for its operational database, so staging attaches a persistent disk. Supabase is validated separately and is reserved for the next database migration phase.

## 1. Repository

Push the MReis AI repository to GitHub. Do not commit `.env`, API keys, Stripe secrets, Supabase secret keys, or local SQLite databases.

## 2. Render

Create a Render account and choose **New → Blueprint**. Select the GitHub repository containing `render.yaml`.

The Blueprint creates `mreis-ai-staging` as a Docker web service, attaches a persistent disk, and configures `/api/health/ready` as the health check.

Render supports persistent disks for paid web services and supports secret environment variables via `sync: false`. See the official Render Blueprint and environment-variable documentation.

## 3. Secrets

In the Render service environment, enter the values for:

- `OPENAI_API_KEY`
- `SUPABASE_URL`
- `SUPABASE_PUBLISHABLE_KEY`
- `SUPABASE_SECRET_KEY`
- `STRIPE_SECRET_KEY` — staging/test mode only
- `STRIPE_WEBHOOK_SECRET`
- `BASE_URL`

Never put these values in `render.yaml`.

## 4. First deploy

Deploy and wait for:

- Build successful
- Health check passing
- `/api/health` returning 200
- `/api/health/ready` returning `ready: true`

Render will provide an HTTPS `onrender.com` URL. Put that exact URL in `BASE_URL`, redeploy, and then use it as the Stripe webhook destination.

## 5. Stripe webhook

Create a Stripe test/sandbox webhook endpoint:

`https://YOUR-STAGING-DOMAIN/api/stripe/webhook`

Subscribe to at least:

- `checkout.session.completed`

Copy the generated webhook signing secret into `STRIPE_WEBHOOK_SECRET` in Render. Do not commit it.

## 6. Verification

After the service is live:

```bash
BASE_URL=https://YOUR-STAGING-DOMAIN npm run staging:e2e
```

For the full OpenAI/Stripe/Supabase connectivity check:

```bash
npm run staging:smoke
```

The commands never print secret values.

## 7. Important architecture note

Version 2.4 staging still stores application data in SQLite on the attached persistent disk. Supabase is connected only as an infrastructure validation target at this stage. The SQLite → Supabase migration must be completed and tested before Supabase can be considered the application's source of truth.
