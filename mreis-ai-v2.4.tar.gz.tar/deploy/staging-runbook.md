# MReis AI — staging runbook v2.0

## External services
1. Create a Supabase project and apply `supabase/migrations/001_initial.sql`.
2. Verify RLS policies with Supabase DB tests before exposing tables.
3. Configure OpenAI server-side using `OPENAI_API_KEY` and `OPENAI_MODEL=gpt-5.6-luna`.
4. Configure Stripe test mode and its webhook signing secret.
5. Set `BASE_URL` to the HTTPS staging URL and `TRUST_PROXY=true` when behind a trusted reverse proxy.

## Secret handling
- Never place secret keys in source control or browser code.
- Supabase publishable keys may be client-side only with correct RLS; secret keys remain backend-only.
- Rotate a secret immediately if it is exposed.

## Acceptance test
Run, in order:
- `npm run preflight`
- `npm run test:static`
- `npm run test:staging-contract`
- `npm run test:runtime:core`
- `npm run test:runtime`
- `npm run test:production-config`
- Supabase RLS test suite
- Stripe test webhook delivery
- OpenAI real Responses API smoke request

A production release requires all applicable checks to pass.
