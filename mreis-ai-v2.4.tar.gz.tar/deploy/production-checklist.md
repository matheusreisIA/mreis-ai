# Production checklist

- [ ] Managed Postgres/Supabase connected
- [ ] RLS policies verified
- [ ] Object storage configured
- [ ] OpenAI production key configured server-side
- [ ] Stripe live mode + webhook secret configured
- [ ] Public HTTPS BASE_URL configured
- [ ] Email provider configured
- [ ] Domain/DNS configured
- [ ] Error monitoring configured
- [ ] Backups and restore test completed
- [ ] Privacy/terms/legal pages published
- [ ] Runtime E2E against staging infrastructure passes
- [ ] Load test and rate-limit review completed
- [ ] Production smoke test passes
