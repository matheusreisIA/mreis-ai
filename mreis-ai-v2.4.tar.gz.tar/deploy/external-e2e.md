# MReis AI — External Staging E2E

Set `STAGING_BASE_URL` to the HTTPS staging origin. The runner exercises the deployed application over the network and does not print secrets.

```bash
npm run staging:smoke
STAGING_BASE_URL=https://staging.example.com npm run staging:e2e
```

The E2E journey validates health, readiness, demo auth, Discover, product generation, PDF export, Launch, test checkout, idempotency, delivery, analytics and account export. Account deletion is destructive and is only executed when `RUN_DESTRUCTIVE_E2E=true`.

For Stripe webhook verification:

```bash
STAGING_BASE_URL=https://staging.example.com npm run staging:webhook
```

This sends a synthetically signed `checkout.session.completed` event to the staging webhook endpoint. It validates signature construction/verification and handler behavior without charging a customer.

A real Stripe payment flow still requires completing a Checkout Session in Stripe's test environment and confirming the resulting webhook delivery in the Stripe Dashboard/CLI.
