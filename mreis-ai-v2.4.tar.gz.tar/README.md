# MReis AI — v2.3.0

**From Idea to Digital Business.**

MReis AI is the intelligent infrastructure for discovering, building, launching and scaling digital products.

## Status

**Version:** 2.3.0  
**Stage:** External Staging E2E Ready  
**Production:** Not connected / not deployed

The codebase has local runtime, static, contract and configuration validation. External staging connectors are prepared but require the user's own infrastructure credentials.

## MREIS METHOD™

1. Discover
2. Build
3. Launch
4. Sell
5. Scale

## Current capabilities

- Demo authentication and session handling
- Market/opportunity discovery
- AI-assisted digital product generation
- PDF export
- Test checkout and order flow
- Delivery endpoint
- Analytics events
- Stripe webhook verification
- Checkout idempotency
- AI credit consumption/refund on generation failure
- Account export and explicit account deletion confirmation
- Security headers, rate limiting and request IDs
- Health/readiness endpoints
- Graceful shutdown
- Docker packaging
- Supabase schema and RLS policy baseline
- OpenAI Responses API provider
- Real staging smoke tests for OpenAI, Stripe and Supabase
- External HTTPS E2E runner
- Signed Stripe webhook smoke test

## Test Mode

The project supports a local/demo mode without external credentials. This is intended for development and automated validation only.

For real staging, create a local `.env.staging` from `.env.staging.example` and provide credentials through your secure environment or secrets manager. Never commit `.env.staging`, API keys, webhook secrets or passwords.

## Real staging sequence

1. Create a dedicated Supabase staging project.
2. Apply `supabase/migrations/001_initial.sql`.
3. Review and run `supabase/tests/rls.sql` against staging.
4. Configure Supabase publishable and secret keys.
5. Configure an OpenAI API key and the staging model.
6. Create a Stripe sandbox/test environment and configure the webhook signing secret.
7. Set `BASE_URL` to the HTTPS staging origin.
8. Run `npm run staging:smoke
npm run staging:e2e
npm run staging:webhook`.
9. Run the application against staging and execute the external E2E journey.
10. Review logs, webhook events, analytics and failure recovery before production.

Supabase's current API-key model uses publishable keys for public components and secret keys only on controlled backends; secret keys bypass RLS and must never be shipped to the browser or source control. citehttps://supabase.com/docs/guides/getting-started/api-keys

## Commands

```bash
npm run preflight
npm run test:static
npm run test:runtime:core
npm run test:staging-contract
npm run test:staging-config
npm run staging:smoke
npm run staging:e2e
npm run staging:webhook
```

`staging:smoke` skips external checks when their credentials are absent. It never prints secret values. A configured staging environment should have zero skipped external checks.

## Environment

See `.env.example`, `.env.staging.example` and `.env.production.example`.

Never send secrets through chat. Put them into the local environment, CI/CD secret store or hosting provider's secret manager.

## Production gate

This repository is **not** a claim of public production deployment. Production requires, at minimum:

- HTTPS and domain
- managed database/storage and backups
- real authentication configuration
- OpenAI production credentials and spend limits
- Stripe production configuration and verified webhooks
- observability and alerting
- external E2E validation
- security review
- privacy/legal documents appropriate to the operating jurisdictions
- rollback and incident procedures


## External staging E2E

Set `STAGING_BASE_URL` to the deployed HTTPS staging origin and run `npm run staging:e2e`. The runner validates the network path through the main application journey without printing secrets. For a disposable account, set `RUN_DESTRUCTIVE_E2E=true` to include account deletion.

`npm run staging:webhook` sends a synthetically signed Stripe `checkout.session.completed` event to the staging endpoint. This validates webhook signature verification and handler behavior without charging a customer.

## Staging deployment target — v2.4

The current production-shaped runtime is a persistent Node/Express service packaged with Docker. `render.yaml` provides a staging deployment target with an attached persistent disk because the current operational database is SQLite.

Supabase credentials can be validated with `npm run staging:smoke`, but Supabase is not yet the application's operational database. The SQLite-to-Supabase migration is a separate controlled phase with RLS and data-integrity tests.

Deployment guide: `deploy/render-staging.md`.
