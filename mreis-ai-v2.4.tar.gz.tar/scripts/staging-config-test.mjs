import fs from 'node:fs';
import assert from 'node:assert/strict';
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const env=fs.readFileSync('.env.staging.example','utf8');
const smoke=fs.readFileSync('scripts/staging-smoke.mjs','utf8');
assert.equal(pkg.version,'2.4.0');
for (const token of ['NODE_ENV=staging','OPENAI_API_KEY','OPENAI_MODEL','STRIPE_SECRET_KEY','SUPABASE_URL','SUPABASE_PUBLISHABLE_KEY','SUPABASE_SECRET_KEY']) assert.ok(env.includes(token),`missing staging env token: ${token}`);
for (const token of ['OpenAI Responses API','Stripe API connectivity','Supabase Auth public endpoint','Supabase REST server endpoint','Secrets are never printed']) assert.ok(smoke.includes(token),`missing smoke contract: ${token}`);
console.log('STAGING CONFIG TEST PASSED');
