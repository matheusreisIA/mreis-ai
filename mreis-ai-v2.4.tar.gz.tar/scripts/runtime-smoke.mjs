import { spawn } from 'node:child_process';
import fs from 'node:fs';
import process from 'node:process';

const port = Number(process.env.TEST_PORT || 3187);
const db = `data/runtime-smoke-${process.pid}.db`;
if (!fs.existsSync('node_modules')) {
  console.error('RUNTIME SKIPPED: node_modules is missing. Run npm install in an environment with npm registry access.');
  process.exit(2);
}

const child = spawn(process.execPath, ['src/server.js'], {
  env: { ...process.env, PORT: String(port), DB_PATH: db, NODE_ENV: 'test', BASE_URL: `http://127.0.0.1:${port}` },
  stdio: ['ignore', 'pipe', 'pipe']
});
let stderr = '';
child.stderr.on('data', b => { stderr += b.toString(); });

const sleep = ms => new Promise(r => setTimeout(r, ms));
async function request(url, options={}) {
  const res = await fetch(`http://127.0.0.1:${port}${url}`, options);
  const text = await res.text();
  let body; try { body = JSON.parse(text); } catch { body = text; }
  return { res, body };
}

try {
  let health;
  for (let i=0;i<40;i++) {
    try { health = await request('/api/health'); if (health.res.ok) break; } catch {}
    await sleep(100);
  }
  if (!health?.res?.ok) throw new Error(`Server did not become ready. ${stderr}`);
  const ready = await request('/api/health/ready');
  if (!ready.res.ok || !ready.body.ready || !ready.body.db) throw new Error(`readiness failed: ${JSON.stringify(ready.body)}`);
  if (!health.res.headers.get('x-request-id')) throw new Error('request id header missing');
  console.log('✓ server boot + health + readiness');

  const demo = await request('/api/auth/demo', {method:'POST',headers:{'content-type':'application/json'},body:'{}'});
  if (!demo.res.ok) throw new Error(`demo auth failed: ${JSON.stringify(demo.body)}`);
  const auth = {Authorization:`Bearer ${demo.body.token}`,'content-type':'application/json'};
  console.log('✓ demo auth');

  const discover = await request('/api/discover',{method:'POST',headers:auth,body:JSON.stringify({market:'France',category:'productivity',problem:'organizing remote work'})});
  if (!discover.res.ok) throw new Error(`discover failed: ${JSON.stringify(discover.body)}`);
  console.log('✓ discover');

  const generated = await request('/api/products/generate',{method:'POST',headers:auth,body:JSON.stringify({projectId:discover.body.projectId,title:'Runtime Test Product'})});
  if (!generated.res.ok) throw new Error(`product generation failed: ${JSON.stringify(generated.body)}`);
  const productId = generated.body.product?.id || generated.body.productId || generated.body.id;
  if (!productId) throw new Error('product id missing');
  console.log('✓ product generation');

  const pdf = await request(`/api/products/${productId}/pdf`,{headers:{Authorization:auth.Authorization}});
  if (!pdf.res.ok || !String(pdf.res.headers.get('content-type')).includes('application/pdf')) throw new Error('pdf export failed');
  console.log('✓ pdf export');

  const checkout = await request('/api/test/checkout',{method:'POST',headers:auth,body:JSON.stringify({productId,priceCents:1490,currency:'eur'})});
  if (!checkout.res.ok) throw new Error(`checkout failed: ${JSON.stringify(checkout.body)}`);
  console.log('✓ test checkout');

  const delivery = await request(checkout.body.deliveryUrl,{headers:{Authorization:auth.Authorization}});
  if (!delivery.res.ok) throw new Error(`delivery failed: ${JSON.stringify(delivery.body)}`);
  console.log('✓ delivery');

  const analytics = await request('/api/analytics',{headers:{Authorization:auth.Authorization}});
  if (!analytics.res.ok || analytics.body.purchases < 1) throw new Error(`analytics failed: ${JSON.stringify(analytics.body)}`);
  console.log('✓ analytics');

  console.log('RUNTIME E2E PASSED');
} catch (e) {
  console.error(`RUNTIME E2E FAILED: ${e.message}`);
  if (stderr) console.error(stderr);
  process.exitCode = 1;
} finally {
  child.kill('SIGTERM');
  try { fs.unlinkSync(db); } catch {}
}
