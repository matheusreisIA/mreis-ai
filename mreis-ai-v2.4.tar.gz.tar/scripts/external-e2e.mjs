import fs from 'node:fs';

function loadDotEnv(){
  for(const file of ['.env.staging','.env']){
    if(!fs.existsSync(file)) continue;
    for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
      const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if(!m || process.env[m[1]]!==undefined) continue;
      let v=m[2]; if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'"))) v=v.slice(1,-1);
      process.env[m[1]]=v;
    }
  }
}
loadDotEnv();

const base=String(process.env.STAGING_BASE_URL||process.env.BASE_URL||'').replace(/\/$/,'');
if(!base){ console.error('STAGING_BASE_URL or BASE_URL is required.'); process.exit(2); }
if(!/^https:\/\//i.test(base)){ console.error('External staging E2E requires HTTPS.'); process.exit(2); }

let token=''; let projectId=''; let productId='';
let pass=0, fail=0;
async function req(path,options={}){
  const headers={...(options.headers||{})};
  if(token) headers.authorization=`Bearer ${token}`;
  if(options.body!==undefined){ headers['content-type']='application/json'; options.body=JSON.stringify(options.body); }
  const r=await fetch(base+path,{...options,headers,redirect:'manual'});
  const ct=r.headers.get('content-type')||'';
  const body=ct.includes('application/json')?await r.json():await r.text();
  return {r,body};
}
function ok(name,condition,detail=''){
  if(condition){pass++;console.log(`✓ ${name}${detail?` — ${detail}`:''}`)}
  else {fail++;console.error(`✗ ${name}${detail?` — ${detail}`:''}`)}
}
function idempotency(){return `mreis-e2e-${Date.now()}-${Math.random().toString(16).slice(2)}`;}

console.log(`MReis AI 2.4.0 — external staging E2E: ${base}`);
try{
  let x=await req('/api/health'); ok('health',x.r.ok && x.body?.ok===true,`HTTP ${x.r.status}`);
  x=await req('/api/health/ready'); ok('readiness',x.r.ok && x.body?.ready===true,`HTTP ${x.r.status}`);
  x=await req('/api/auth/demo',{method:'POST',body:{}}); token=x.body?.token||''; ok('demo authentication',x.r.ok && !!token,`HTTP ${x.r.status}`);
  x=await req('/api/discover',{method:'POST',body:{market:'France',language:'French',category:'productivity',problem:'organize a recurring administrative workflow'}}); projectId=x.body?.id||''; ok('Discover',x.r.ok && !!projectId,`HTTP ${x.r.status}`);
  x=await req('/api/products/generate',{method:'POST',body:{projectId}}); productId=x.body?.id||''; ok('Product generation',x.r.ok && !!productId,`HTTP ${x.r.status}`);
  x=await req(`/api/products/${productId}/pdf`); ok('PDF export',x.r.ok && (x.r.headers.get('content-type')||'').includes('application/pdf'),`HTTP ${x.r.status}`);
  x=await req('/api/campaigns/generate',{method:'POST',body:{productId,market:'France',language:'French'}}); ok('Launch kit generation',x.r.ok && !!x.body?.result,`HTTP ${x.r.status}`);
  const key=idempotency();
  x=await req('/api/test/checkout',{method:'POST',headers:{'Idempotency-Key':key},body:{productId,priceCents:1490,currency:'eur'}}); const first=x.body; ok('Test checkout',x.r.ok && first?.test===true && !!first?.orderId,`HTTP ${x.r.status}`);
  const y=await req('/api/test/checkout',{method:'POST',headers:{'Idempotency-Key':key},body:{productId,priceCents:1490,currency:'eur'}}); ok('Checkout idempotency',y.r.ok && y.body?.orderId===first?.orderId,`HTTP ${y.r.status}`);
  if(first?.deliveryUrl){ x=await req(first.deliveryUrl); ok('Delivery',x.r.ok && !!x.body,`HTTP ${x.r.status}`); }
  x=await req('/api/analytics'); ok('Analytics',x.r.ok && typeof x.body?.projects==='number',`HTTP ${x.r.status}`);
  x=await req('/api/account/export'); ok('Account export',x.r.ok && !!x.body?.user,`HTTP ${x.r.status}`);
  if(process.env.RUN_DESTRUCTIVE_E2E==='true'){
    x=await req('/api/account/delete',{method:'POST',body:{confirmation:'DELETE MY ACCOUNT'}}); ok('Account deletion',x.r.ok && x.body?.deleted===true,`HTTP ${x.r.status}`);
  } else console.log('○ Account deletion — SKIP: set RUN_DESTRUCTIVE_E2E=true for disposable-account deletion test');
}catch(e){ fail++; console.error(`✗ E2E runner — ${e?.message||e}`); }
console.log(`\nEXTERNAL E2E SUMMARY: ${pass} passed, ${fail} failed`);
process.exit(fail?1:0);
