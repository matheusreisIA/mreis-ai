import fs from 'node:fs';
import pkg from '../package.json' with { type: 'json' };
const server=fs.readFileSync(new URL('../src/server.js',import.meta.url),'utf8');
const core=fs.readFileSync(new URL('../src/core-runtime.mjs',import.meta.url),'utf8');
if(pkg.version!=='2.4.0')throw new Error(`package version mismatch: ${pkg.version}`);
if(!server.includes("APP_VERSION = '2.4.0'"))throw new Error('production server version mismatch');
if(!core.includes("APP_VERSION = '2.4.0'"))throw new Error('core runtime version mismatch');
console.log('PRELIGHT PASS: v2.4.0 version alignment');
