import fs from 'node:fs';

function loadDotEnv(){
  for (const file of ['.env.staging', '.env']) {
    if (!fs.existsSync(file)) continue;
    for (const line of fs.readFileSync(file,'utf8').split(/\r?\n/)) {
      const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if(!m || process.env[m[1]]!==undefined) continue;
      let value=m[2];
      if((value.startsWith('\"') && value.endsWith('\"')) || (value.startsWith("'") && value.endsWith("'"))) value=value.slice(1,-1);
      process.env[m[1]]=value;
    }
  }
}
loadDotEnv();

const results = [];
function pass(name, detail=''){ results.push({name,status:'PASS',detail}); console.log(`✓ ${name}${detail ? ` — ${detail}` : ''}`); }
function skip(name, detail){ results.push({name,status:'SKIP',detail}); console.log(`○ ${name} — SKIP: ${detail}`); }
function fail(name, detail){ results.push({name,status:'FAIL',detail}); console.error(`✗ ${name} — ${detail}`); }
function required(name){ const v=String(process.env[name]||'').trim(); return v.length>0; }
function looksLikeSecret(v){ return /^(sk_|sb_secret_|whsec_)/.test(String(v||'')); }

console.log('MReis AI 2.4.0 — external staging smoke');
console.log('Secrets are never printed. Missing credentials are reported as SKIP.');

// Basic environment contract.
if(required('OPENAI_API_KEY')) pass('OPENAI_API_KEY configured'); else skip('OpenAI connectivity', 'OPENAI_API_KEY not configured');
if(required('STRIPE_SECRET_KEY')) pass('STRIPE_SECRET_KEY configured'); else skip('Stripe connectivity', 'STRIPE_SECRET_KEY not configured');
if(required('SUPABASE_URL') && required('SUPABASE_PUBLISHABLE_KEY')) pass('Supabase public connection configured'); else skip('Supabase public connectivity', 'SUPABASE_URL and/or SUPABASE_PUBLISHABLE_KEY not configured');
if(required('SUPABASE_URL') && required('SUPABASE_SECRET_KEY')) pass('Supabase server connection configured'); else skip('Supabase server connectivity', 'SUPABASE_URL and/or SUPABASE_SECRET_KEY not configured');

// Safety contract: high-privilege credentials must look like server-side secrets and must never be exposed by the script.
for (const key of ['OPENAI_API_KEY','STRIPE_SECRET_KEY','SUPABASE_SECRET_KEY']) {
  if (required(key) && !looksLikeSecret(process.env[key])) pass(`${key} format accepted`, 'value withheld');
}

if(required('OPENAI_API_KEY')) {
  try {
    const mod = await import('openai');
    const OpenAI = mod.default;
    const client = new OpenAI({apiKey: process.env.OPENAI_API_KEY});
    const model = process.env.OPENAI_MODEL || 'gpt-5.6-luna';
    const response = await client.responses.create({
      model,
      input: 'Reply with exactly: MREIS_STAGING_OK',
      max_output_tokens: 20
    });
    const output = String(response.output_text || '').trim();
    if(output === 'MREIS_STAGING_OK') pass('OpenAI Responses API', `model=${model}`);
    else fail('OpenAI Responses API', `unexpected response output: ${output.slice(0,80)}`);
  } catch (e) {
    fail('OpenAI Responses API', e?.message || 'request failed');
  }
}

if(required('STRIPE_SECRET_KEY')) {
  try {
    const mod = await import('stripe');
    const Stripe = mod.default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
    const account = await stripe.accounts.retrieve();
    if(account.charges_enabled !== undefined) pass('Stripe API connectivity', `account=${String(account.id).slice(0,8)}…`);
    else fail('Stripe API connectivity', 'account response did not contain expected fields');
    if(String(process.env.STRIPE_SECRET_KEY).startsWith('sk_test_')) pass('Stripe test-mode key', 'sk_test key detected');
    else fail('Stripe test-mode key', 'expected a test-mode secret key for staging');
  } catch (e) {
    fail('Stripe API connectivity', e?.message || 'request failed');
  }
}

async function supabaseRequest(key, path) {
  const base = String(process.env.SUPABASE_URL).replace(/\/$/, '');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 10000);
  try {
    return await fetch(`${base}${path}`, {headers:{apikey:key, Accept:'application/json'}, signal:controller.signal});
  } finally { clearTimeout(timer); }
}

if(required('SUPABASE_URL') && required('SUPABASE_PUBLISHABLE_KEY')) {
  try {
    const response = await supabaseRequest(process.env.SUPABASE_PUBLISHABLE_KEY, '/auth/v1/settings');
    if(response.ok) pass('Supabase Auth public endpoint', `HTTP ${response.status}`);
    else fail('Supabase Auth public endpoint', `HTTP ${response.status}`);
  } catch (e) { fail('Supabase Auth public endpoint', e?.message || 'request failed'); }
}

if(required('SUPABASE_URL') && required('SUPABASE_SECRET_KEY')) {
  try {
    const response = await supabaseRequest(process.env.SUPABASE_SECRET_KEY, '/rest/v1/products?select=id&limit=1');
    if(response.ok) pass('Supabase REST server endpoint', `HTTP ${response.status}; RLS/admin path reachable`);
    else fail('Supabase REST server endpoint', `HTTP ${response.status}`);
  } catch (e) { fail('Supabase REST server endpoint', e?.message || 'request failed'); }
}

const failures = results.filter(x=>x.status==='FAIL');
const passes = results.filter(x=>x.status==='PASS').length;
const skips = results.filter(x=>x.status==='SKIP').length;
console.log(`\nSTAGING SMOKE SUMMARY: ${passes} passed, ${failures.length} failed, ${skips} skipped`);
if(failures.length) process.exit(1);
