import fs from 'node:fs';
import assert from 'node:assert/strict';
const schema=fs.readFileSync('supabase/migrations/001_initial.sql','utf8');
const adapter=fs.readFileSync('src/providers/openai-responses.mjs','utf8');
const env=fs.readFileSync('.env.production.example','utf8');
for (const token of ['auth.users','enable row level security','projects_owner_all','products_owner_all','orders_owner_select','events_owner_select']) assert.ok(schema.toLowerCase().includes(token.toLowerCase()), `missing schema contract: ${token}`);
for (const token of ['responses.create','text: { format: { type: \'json_object\' } }','gpt-5.6-luna']) assert.ok(adapter.includes(token), `missing OpenAI adapter contract: ${token}`);
for (const token of ['SUPABASE_URL','SUPABASE_PUBLISHABLE_KEY','SUPABASE_SECRET_KEY','OPENAI_API_KEY','STRIPE_SECRET_KEY']) assert.ok(env.includes(token), `missing env contract: ${token}`);
console.log('STAGING CONTRACT: PASS');
