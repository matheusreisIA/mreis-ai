import fs from 'node:fs';
import path from 'node:path';
const root=process.cwd();
const pkg=JSON.parse(fs.readFileSync(path.join(root,'package.json'),'utf8'));
const server=fs.readFileSync(path.join(root,'src/server.js'),'utf8');
const core=fs.readFileSync(path.join(root,'src/core-runtime.mjs'),'utf8');
const readme=fs.readFileSync(path.join(root,'README.md'),'utf8');
const checks=[
 ['version package/server',pkg.version===server.match(/APP_VERSION = '([^']+)'/)[1]],
 ['version server/core',server.match(/APP_VERSION = '([^']+)'/)[1]===core.match(/APP_VERSION = '([^']+)'/)[1]],
 ['production env gate',server.includes('productionConfigIssues') && server.includes('IS_PRODUCTION')],
 ['no secret values in readiness',server.includes('issues') && !server.match(/res\.json\([^\n]*OPENAI_API_KEY/)],
 ['dockerfile present',fs.existsSync(path.join(root,'Dockerfile'))],
 ['production checklist present',fs.existsSync(path.join(root,'deploy/production-checklist.md'))],
 ['runtime validation docs',fs.existsSync(path.join(root,'deploy/runtime-validation.md'))],
 ['test mode documented',readme.toLowerCase().includes('test mode') || readme.toLowerCase().includes('demo')]
];
let failed=0; for(const [name,ok] of checks){console.log(`${ok?'✓':'✗'} ${name}`);if(!ok)failed++;}
if(failed) process.exit(1); console.log(`PRODUCTION CONFIG TEST PASSED: ${checks.length}/${checks.length}`);
