import { spawn } from 'node:child_process';
import fs from 'node:fs';
import process from 'node:process';
const port=Number(process.env.CORE_TEST_PORT||3297);const db=`data/core-e2e-${process.pid}.db`;
const child=spawn(process.execPath,['src/core-runtime.mjs'],{env:{...process.env,CORE_PORT:String(port),CORE_DB_PATH:db},stdio:['ignore','pipe','pipe']});let stderr='';child.stderr.on('data',b=>stderr+=b.toString());
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
async function req(path,options={}){const r=await fetch(`http://127.0.0.1:${port}${path}`,options);const type=r.headers.get('content-type')||'';const body=type.includes('json')?await r.json():await r.arrayBuffer();return {r,body}}
try{
 let h;for(let i=0;i<50;i++){try{h=await req('/api/health');if(h.r.ok)break}catch{}await sleep(100)}
 if(!h?.r?.ok)throw new Error('core server failed to boot');console.log('✓ core boot + health');
 const ready=await req('/api/health/ready');if(!ready.r.ok||!ready.body.ready)throw new Error('readiness failed');console.log('✓ readiness');
 const demo=await req('/api/auth/demo',{method:'POST'});if(!demo.r.ok)throw new Error('demo auth failed');const auth={Authorization:`Bearer ${demo.body.token}`,'content-type':'application/json'};console.log('✓ auth');
 const dis=await req('/api/discover',{method:'POST',headers:auth,body:JSON.stringify({market:'France',category:'productivity',problem:'organizing remote work'})});if(!dis.r.ok)throw new Error('discover failed');console.log('✓ discover');
 const gen=await req('/api/products/generate',{method:'POST',headers:auth,body:JSON.stringify({projectId:dis.body.projectId,title:'Runtime E2E Product'})});if(!gen.r.ok)throw new Error('product generation failed');const productId=gen.body.productId;console.log('✓ build');
 const pdf=await req(`/api/products/${productId}/pdf`,{headers:{Authorization:auth.Authorization}});if(!pdf.r.ok||!String(pdf.r.headers.get('content-type')).includes('application/pdf'))throw new Error('pdf failed');console.log('✓ pdf');
 const checkout=await req('/api/test/checkout',{method:'POST',headers:auth,body:JSON.stringify({productId,priceCents:1490,currency:'eur'})});if(!checkout.r.ok)throw new Error('checkout failed');console.log('✓ sell / checkout');
 const delivery=await req(checkout.body.deliveryUrl,{headers:{Authorization:auth.Authorization}});if(!delivery.r.ok)throw new Error('delivery failed');console.log('✓ delivery');
 const analytics=await req('/api/analytics',{headers:{Authorization:auth.Authorization}});if(!analytics.r.ok||analytics.body.purchases!==1)throw new Error('analytics failed');console.log('✓ analytics');
 console.log('RUNTIME CORE E2E PASSED');
}catch(e){console.error(`RUNTIME CORE E2E FAILED: ${e.message}`);if(stderr)console.error(stderr);process.exitCode=1}finally{child.kill('SIGTERM');await sleep(100);try{fs.unlinkSync(db)}catch{}}
