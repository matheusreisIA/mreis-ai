import fs from 'node:fs';
import { spawnSync } from 'node:child_process';
const server='src/server.js';
const source=fs.readFileSync(server,'utf8');
const syntax=spawnSync(process.execPath,['--check',server],{encoding:'utf8'});
const pkg=JSON.parse(fs.readFileSync('package.json','utf8'));
const assertions=[
 ['server syntax', syntax.status===0],
 ['version consistency', pkg.version==='2.4.0' && source.includes("const APP_VERSION = '2.4.0'")],
 ['schema before session cleanup', source.indexOf('CREATE TABLE IF NOT EXISTS sessions') < source.indexOf("DELETE FROM sessions WHERE expires_at < ?")],
 ['health endpoint', source.includes("app.get('/api/health'" )],
 ['readiness endpoint', source.includes("app.get('/api/health/ready'")],
 ['request id middleware', source.includes('X-Request-Id')],
 ['graceful shutdown', source.includes('server.close(resolve)')],
 ['demo auth', source.includes("app.post('/api/auth/demo'" )],
 ['discover endpoint', source.includes("app.post('/api/discover'" )],
 ['product generation', source.includes("app.post('/api/products/generate'" )],
 ['pdf export', source.includes("/api/products/:id/pdf")],
 ['test checkout', source.includes("/api/test/checkout")],
 ['delivery endpoint', source.includes("/api/orders/:id/delivery")],
 ['analytics endpoint', source.includes("/api/analytics")],
 ['stripe webhook', source.includes("/api/stripe/webhook")],
 ['credit refund on AI failure', source.includes('refundCredits(req.user.id,cost)')],
 ['production model configurable', source.includes("process.env.OPENAI_MODEL||'gpt-5.6-luna'")],
 ['webhook signature verification', source.includes('stripe.webhooks.constructEvent')],
 ['hashed session identifiers', source.includes('function sessionId(raw)') && source.includes('sessionId(t)')],
 ['expired session cleanup', source.includes("DELETE FROM sessions WHERE expires_at < ?")],
 ['password length ceiling', source.includes('password.length>128')],
 ['account export', source.includes("/api/account/export")],
 ['account deletion confirmation', source.includes("DELETE MY ACCOUNT")],
 ['checkout idempotency', source.includes("Idempotency-Key") && source.includes('idempotency_keys')],
 ['transactional test checkout', source.includes('db.transaction(()=>')],
];
for (const [name,ok] of assertions) console.log(`${ok?'✓':'✗'} ${name}`);
if (syntax.status!==0) console.error(syntax.stderr);
if (assertions.some(([,ok])=>!ok)) process.exit(1);
console.log(`Static test passed: ${assertions.length}/${assertions.length}`);
