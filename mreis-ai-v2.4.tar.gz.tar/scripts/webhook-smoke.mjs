import fs from 'node:fs';
import Stripe from 'stripe';

function loadDotEnv(){
  for(const file of ['.env.staging','.env']){
    if(!fs.existsSync(file)) continue;
    for(const line of fs.readFileSync(file,'utf8').split(/\r?\n/)){
      const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
      if(!m || process.env[m[1]]!==undefined) continue;
      let v=m[2]; if((v.startsWith('"')&&v.endsWith('"'))||(v.startsWith("'")&&v.endsWith("'"))) v=v.slice(1,-1);
      process.env[m[1]]=v;
    }
  }
}
loadDotEnv();
const base=String(process.env.STAGING_BASE_URL||process.env.BASE_URL||'').replace(/\/$/,'');
const secret=String(process.env.STRIPE_WEBHOOK_SECRET||'');
if(!base || !/^https:\/\//i.test(base)) { console.error('STAGING_BASE_URL/BASE_URL must be an HTTPS staging URL.'); process.exit(2); }
if(!secret || !secret.startsWith('whsec_')) { console.error('STRIPE_WEBHOOK_SECRET must be configured for webhook smoke.'); process.exit(2); }

const stripe=new Stripe(process.env.STRIPE_SECRET_KEY||'sk_test_placeholder');
const event={id:`evt_mreis_smoke_${Date.now()}`,object:'event',api_version:'2025-06-30.basil',created:Math.floor(Date.now()/1000),data:{object:{id:`cs_test_mreis_${Date.now()}`,object:'checkout.session',amount_total:1490,currency:'eur',customer_details:{email:'staging@mreis.ai'},metadata:{userId:'',productId:''}}},livemode:false,pending_webhooks:1,request:null,type:'checkout.session.completed'};
const payload=JSON.stringify(event);
const signature=stripe.webhooks.generateTestHeaderString({payload,secret});
const r=await fetch(base+'/api/stripe/webhook',{method:'POST',headers:{'content-type':'application/json','stripe-signature':signature},body:payload});
const text=await r.text();
if(!r.ok){console.error(`✗ Stripe webhook smoke HTTP ${r.status}: ${text.slice(0,200)}`);process.exit(1);}
console.log(`✓ Stripe webhook signature/handler — HTTP ${r.status}`);
console.log('WEBHOOK SMOKE PASSED');
