-- Review with `supabase test db` in the Supabase CLI environment.
-- Contract: authenticated users may access only rows where user_id = auth.uid().
-- Anonymous clients must not read or mutate application tables.
select 1 as rls_contract;
