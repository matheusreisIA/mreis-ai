-- MReis AI production schema
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  plan text not null default 'free' check (plan in ('free','starter','pro','business')),
  credits integer not null default 20 check (credits >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  input jsonb not null,
  result jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  project_id uuid references public.projects(id) on delete set null,
  data jsonb not null,
  created_at timestamptz not null default now()
);

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  product_id uuid references public.products(id) on delete set null,
  provider text not null default 'stripe',
  provider_id text unique,
  status text not null,
  amount integer,
  currency text,
  email text,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  type text not null,
  product_id uuid references public.products(id) on delete set null,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index if not exists projects_user_id_idx on public.projects(user_id);
create index if not exists products_user_id_idx on public.products(user_id);
create index if not exists orders_user_id_idx on public.orders(user_id);
create index if not exists events_user_id_idx on public.events(user_id);

alter table public.profiles enable row level security;
alter table public.projects enable row level security;
alter table public.products enable row level security;
alter table public.orders enable row level security;
alter table public.events enable row level security;

create policy "profiles_owner_select" on public.profiles for select to authenticated using (id = auth.uid());
create policy "profiles_owner_update" on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "projects_owner_all" on public.projects for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "products_owner_all" on public.products for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "orders_owner_select" on public.orders for select to authenticated using (user_id = auth.uid());
create policy "events_owner_select" on public.events for select to authenticated using (user_id = auth.uid());
